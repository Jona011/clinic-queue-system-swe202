const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const money = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'EUR'}).format(n);
const todayISO = () => new Date().toISOString().slice(0,10);
const uid = p => `${p}-${Math.random().toString(16).slice(2,8)}-${Date.now().toString(36)}`;
const storeKey = 'cliniccore_crm_pro_v2';

const roles = {
  admin: {label:'Super Admin', icon:'◆'}, doctor:{label:'Doctor',icon:'◆'}, receptionist:{label:'Receptionist',icon:'◆'}, patient:{label:'Patient',icon:'◆'}, hr:{label:'HR Manager',icon:'◆'}, finance:{label:'Finance',icon:'◆'}, security:{label:'Cybersecurity',icon:'◆'}
};
const nav = {
  admin:['dashboard','patients','appointments','queue','consultations','prescriptions','hr','finance','security','reports','settings'],
  doctor:['doctorDashboard','queue','consultations','patients','prescriptions','lab','reports'],
  receptionist:['receptionDashboard','patients','appointments','queue','billingLite','notifications'],
  patient:['patientDashboard','bookAppointment','myRecords','myInvoices','notifications'],
  hr:['hrDashboard','employees','schedules','leave','reports'],
  finance:['financeDashboard','invoices','payments','pricing','reports'],
  security:['securityDashboard','audit','access','backups','settings']
};
const pageInfo = {
  dashboard:['Command Center','Full clinic overview with live operations, revenue, alerts and staff workload.','▪'],
  patients:['Patient CRM','Manage complete patient profiles, medical history, insurance and emergency contacts.','▪'],
  appointments:['Appointments','Book, approve, reschedule and monitor clinic appointments.','▪'],
  queue:['Live Queue','Real-time waiting room, tickets, emergency priority and consultation flow.','▪'],
  consultations:['Consultations','Doctor notes, symptoms, diagnosis, treatment plans and follow-up.','▪'],
  prescriptions:['Prescriptions','Medication instructions generated from consultations.','▪'],
  hr:['HR Overview','Staff, departments, attendance, shifts and leave requests.','▪'],
  finance:['Finance Overview','Revenue, invoices, payments, refunds and service pricing.','▪'],
  security:['Security Center','Failed logins, suspicious activity, audit trail and access control.','▪'],
  reports:['Reports & Analytics','Operational, financial and clinical performance insights.','▪'],
  settings:['Settings','System preferences, clinic details and configuration.','▪'],
  doctorDashboard:['Doctor Panel','Today schedule, patient queue and consultation workspace.','▪'],
  receptionDashboard:['Receptionist Panel','Front desk check-ins, bookings, walk-ins and queue control.','▪'],
  patientDashboard:['Patient Portal','Your appointments, queue position, prescriptions and invoices.','▪'],
  bookAppointment:['Book Appointment','Create a new appointment with preferred doctor and specialty.','▪'],
  myRecords:['My Medical Records','View your own consultations, prescriptions and history.','▪'],
  myInvoices:['My Invoices','View and download your billing information.','▪'],
  notifications:['Notifications','Reminders, queue updates, alerts and messages.','▪'],
  hrDashboard:['HR Panel','Staff schedule, attendance and leave request monitoring.','▪'],
  employees:['Employees','Manage employee records and contracts.','▪'],
  schedules:['Schedules','Doctor and staff shift planning.','▪'],
  leave:['Leave Requests','Approve or reject employee leave requests.','▪'],
  financeDashboard:['Finance Panel','Revenue, payments and invoice control.','▪'],
  invoices:['Invoices','Create, update, pay and export invoices.','▪'],
  payments:['Payments','Track cash, card, transfer and insurance payments.','▪'],
  pricing:['Service Pricing','Manage consultation and clinic service prices.','▪'],
  securityDashboard:['Cybersecurity Panel','Security alerts, active sessions and failed login monitoring.','▪'],
  audit:['Audit Logs','Every critical action recorded for compliance.','▪'],
  access:['Access Control','Role permissions and sensitive module access matrix.','▪'],
  backups:['Backups','Backup status and data recovery overview.','▪'],
  lab:['Lab Requests','Track lab tests requested by doctors.','▪'],
  billingLite:['Billing','Quick billing for reception desk.','▪']
};

const seed = () => ({
  currentRole:'admin', currentPage:'dashboard', dark:false,
  users:[
    {id:'u1',name:'Admin User',email:'admin@cliniccore.local',role:'admin',status:'Active'},
    {id:'u2',name:'Dr. Arben Hoxha',email:'doctor@cliniccore.local',role:'doctor',status:'Active'},
    {id:'u3',name:'Elira Dervishi',email:'reception@cliniccore.local',role:'receptionist',status:'Active'},
    {id:'u4',name:'Mira Kola',email:'patient@cliniccore.local',role:'patient',status:'Active'},
    {id:'u5',name:'HR Manager',email:'hr@cliniccore.local',role:'hr',status:'Active'},
    {id:'u6',name:'Finance Manager',email:'finance@cliniccore.local',role:'finance',status:'Active'},
    {id:'u7',name:'Security Officer',email:'security@cliniccore.local',role:'security',status:'Active'}
  ],
  patients:[
    {id:'p1',code:'PT-1001',name:'Mira Kola',phone:'+355 69 111 2222',email:'mira@example.com',gender:'Female',dob:'1997-05-14',blood:'A+',allergies:'Penicillin',chronic:'Asthma',insurance:'Sigal',emergency:'Ardit Kola +355691112223',address:'Tirana'},
    {id:'p2',code:'PT-1002',name:'Andi Prifti',phone:'+355 68 333 4444',email:'andi@example.com',gender:'Male',dob:'1989-10-01',blood:'O+',allergies:'None',chronic:'Hypertension',insurance:'Private',emergency:'Sara Prifti +355683334445',address:'Durres'},
    {id:'p3',code:'PT-1003',name:'Lea Basha',phone:'+355 67 777 8888',email:'lea@example.com',gender:'Female',dob:'2001-02-20',blood:'B-',allergies:'Ibuprofen',chronic:'None',insurance:'None',emergency:'Alba Basha +355677778889',address:'Elbasan'},
    {id:'p4',code:'PT-1004',name:'Gent Hysa',phone:'+355 69 909 1212',email:'gent@example.com',gender:'Male',dob:'1978-11-23',blood:'AB+',allergies:'Latex',chronic:'Diabetes',insurance:'Albsig',emergency:'Ema Hysa +355699091213',address:'Tirana'}
  ],
  doctors:[
    {id:'d1',userId:'u2',name:'Dr. Arben Hoxha',specialty:'Cardiology',license:'AL-MD-4421',fee:45,status:'Available',department:'Internal Medicine'},
    {id:'d2',userId:'u8',name:'Dr. Jona Kovaci',specialty:'Dermatology',license:'AL-MD-9920',fee:35,status:'Busy',department:'Dermatology'},
    {id:'d3',userId:'u9',name:'Dr. Klea Rama',specialty:'Pediatrics',license:'AL-MD-3318',fee:30,status:'Available',department:'Pediatrics'}
  ],
  appointments:[
    {id:'a1',patientId:'p1',doctorId:'d1',date:todayISO(),time:'09:30',reason:'Chest discomfort follow-up',status:'Checked In',createdBy:'Receptionist'},
    {id:'a2',patientId:'p2',doctorId:'d1',date:todayISO(),time:'10:00',reason:'Blood pressure control',status:'In Queue',createdBy:'Patient'},
    {id:'a3',patientId:'p3',doctorId:'d2',date:todayISO(),time:'11:00',reason:'Skin allergy consultation',status:'Confirmed',createdBy:'Receptionist'},
    {id:'a4',patientId:'p4',doctorId:'d3',date:todayISO(),time:'12:00',reason:'Diabetes checkup',status:'Pending',createdBy:'Patient'}
  ],
  queue:[
    {id:'q1',ticket:'A001',patientId:'p1',doctorId:'d1',appointmentId:'a1',priority:'Normal',status:'Waiting',eta:8,checkedIn:'09:10'},
    {id:'q2',ticket:'A002',patientId:'p2',doctorId:'d1',appointmentId:'a2',priority:'High',status:'Called',eta:2,checkedIn:'09:20'},
    {id:'q3',ticket:'B001',patientId:'p3',doctorId:'d2',appointmentId:'a3',priority:'Normal',status:'Waiting',eta:22,checkedIn:'10:15'}
  ],
  consultations:[
    {id:'c1',appointmentId:'a0',patientId:'p4',doctorId:'d1',date:'2026-05-20',symptoms:'Fatigue, increased thirst',diagnosis:'Type 2 diabetes follow-up',treatment:'Diet control, medication adjustment',notes:'Patient should monitor glucose daily.',follow:'2026-06-20'}
  ],
  prescriptions:[
    {id:'rx1',patientId:'p4',doctorId:'d1',medicine:'Metformin',dosage:'500mg',frequency:'Twice daily',duration:'30 days',instructions:'Take after meals.',date:'2026-05-20'}
  ],
  invoices:[
    {id:'inv1',number:'INV-2026-001',patientId:'p4',doctorId:'d1',service:'Consultation',amount:45,discount:0,tax:0,total:45,status:'Paid',method:'Card',date:'2026-05-20'},
    {id:'inv2',number:'INV-2026-002',patientId:'p2',doctorId:'d1',service:'Cardiology Consultation',amount:45,discount:5,tax:0,total:40,status:'Unpaid',method:'-',date:todayISO()}
  ],
  employees:[
    {id:'e1',name:'Dr. Arben Hoxha',role:'Doctor',department:'Internal Medicine',contract:'Full-time',salary:1800,status:'Active'},
    {id:'e2',name:'Elira Dervishi',role:'Receptionist',department:'Front Desk',contract:'Full-time',salary:650,status:'Active'},
    {id:'e3',name:'Nora Lika',role:'Nurse',department:'Pediatrics',contract:'Part-time',salary:520,status:'Active'},
    {id:'e4',name:'Klodian Mema',role:'Finance Officer',department:'Finance',contract:'Full-time',salary:900,status:'Active'}
  ],
  leave:[
    {id:'l1',employee:'Nora Lika',type:'Annual Leave',from:'2026-06-03',to:'2026-06-07',status:'Pending'},
    {id:'l2',employee:'Dr. Arben Hoxha',type:'Conference',from:'2026-06-12',to:'2026-06-13',status:'Approved'}
  ],
  services:[
    {id:'s1',name:'General Consultation',price:30}, {id:'s2',name:'Cardiology Consultation',price:45}, {id:'s3',name:'Dermatology Visit',price:35}, {id:'s4',name:'Lab Test Basic',price:20}
  ],
  notifications:[
    {id:'n1',to:'Patient',text:'Your appointment is confirmed for today at 10:00.',status:'Unread',date:todayISO()},
    {id:'n2',to:'Doctor',text:'High priority patient added to your queue.',status:'Unread',date:todayISO()},
    {id:'n3',to:'Finance',text:'New unpaid invoice generated.',status:'Read',date:todayISO()}
  ],
  audit:[
    {id:'log1',user:'Admin User',action:'Logged in',module:'Auth',risk:'Low',time:'09:02',ip:'192.168.1.10'},
    {id:'log2',user:'Elira Dervishi',action:'Checked in patient PT-1001',module:'Queue',risk:'Low',time:'09:12',ip:'192.168.1.22'},
    {id:'log3',user:'Unknown',action:'Failed login attempt',module:'Security',risk:'Medium',time:'09:33',ip:'185.32.91.10'}
  ],
  alerts:[
    {id:'al1',title:'3 failed login attempts',severity:'Medium',status:'Open'},
    {id:'al2',title:'Daily backup completed',severity:'Low',status:'Resolved'}
  ],
  backups:[
    {id:'b1',type:'Database',status:'Completed',time:'02:00',size:'42 MB'},
    {id:'b2',type:'Documents',status:'Completed',time:'02:15',size:'1.2 GB'}
  ]
});
let db = JSON.parse(localStorage.getItem(storeKey) || 'null') || seed();
const save = () => localStorage.setItem(storeKey, JSON.stringify(db));
const addLog = (action,module='System',risk='Low') => {db.audit.unshift({id:uid('log'),user:currentUser().name,action,module,risk,time:new Date().toLocaleTimeString().slice(0,5),ip:'127.0.0.1'}); save();};
function currentUser(){ return db.users.find(u=>u.role===db.currentRole) || db.users[0]; }
function patientName(id){return db.patients.find(p=>p.id===id)?.name || 'Unknown';}
function doctorName(id){return db.doctors.find(d=>d.id===id)?.name || 'Unassigned';}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function statusClass(s){s=String(s).toLowerCase(); if(['paid','completed','approved','active','available','resolved','confirmed'].some(x=>s.includes(x)))return'st-green'; if(['checked','called','in queue','open'].some(x=>s.includes(x)))return'st-blue'; if(['pending','waiting','unpaid','medium','busy'].some(x=>s.includes(x)))return'st-yellow'; if(['cancelled','failed','high','locked','rejected'].some(x=>s.includes(x)))return'st-red'; return 'st-gray';}
function badge(s){return `<span class="status ${statusClass(s)}">${esc(s)}</span>`}
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;$('#toastHost').appendChild(t);setTimeout(()=>t.remove(),2800)}

function render(){
  if(!localStorage.getItem('cliniccore_logged')) return renderLogin();
  const items = nav[db.currentRole] || nav.admin;
  if(!items.includes(db.currentPage)) db.currentPage = items[0];
  const u=currentUser();
  $('#app').innerHTML = `
  <div class="app-shell">
    <aside class="sidebar" id="sidebar">
      <div class="side-brand"><div class="brand-mark">C</div><div><h2>ClinicCore CRM</h2><small>Pro healthcare workspace</small></div></div>
      <div class="card" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.12);box-shadow:none;color:white;padding:14px">
        <div class="role-badge">${roles[db.currentRole].label}</div>
        <div style="margin-top:12px;font-weight:900">${esc(u.name)}</div><small style="color:#94a3b8">${esc(u.email)}</small>
      </div>
      <div class="nav-section">Workspace</div>
      ${items.map(p=>`<button class="nav-btn ${db.currentPage===p?'active':''}" onclick="go('${p}')"><span>${pageInfo[p]?.[2]||'•'}</span>${pageInfo[p]?.[0]||p}</button>`).join('')}
      <div class="nav-section">Switch Role</div>
      ${Object.keys(roles).map(r=>`<button class="nav-btn ${db.currentRole===r?'active':''} " onclick="switchRole('${r}')">${roles[r].label}</button>`).join('')}
    </aside>
    <main class="main">
      <div class="topbar">
        <button class="btn mobile-toggle" onclick="$('#sidebar').classList.toggle('open')">☰</button>
        <div class="search"><span>�</span><input id="globalSearch" placeholder="Search patients, appointments, invoices, staff..." oninput="quickSearch(this.value)"></div>
        <div class="top-actions"><button class="btn" onclick="print()">Print</button><button class="btn" onclick="exportJSON()">Export</button><button class="btn btn-dark" onclick="logout()">Logout</button><div class="avatar">${u.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div></div>
      </div>
      <div class="content" id="content">${page()}</div>
    </main>
  </div>`;
}
function renderLogin(){
 $('#app').innerHTML = `<div class="login-wrap">
  <section class="login-hero"><div class="brand"><div class="brand-mark">C</div>ClinicCore CRM Pro</div><div class="hero-copy"><h1>One clean CRM for the whole clinic.</h1><p>Interactive healthcare management system with doctor, receptionist, patient, HR, finance and cybersecurity panels. Built as a functional frontend prototype for your SWE project.</p><div class="hero-grid"><div class="hero-card"><b>${db.patients.length}</b><span>Patient CRM records</span></div><div class="hero-card"><b>${db.queue.length}</b><span>Live queue tickets</span></div><div class="hero-card"><b>${money(db.invoices.reduce((a,i)=>a+i.total,0))}</b><span>Total invoice value</span></div><div class="hero-card"><b>${db.audit.length}</b><span>Audit log events</span></div></div></div><small>Local demo: no backend required. Data persists in browser LocalStorage.</small></section>
  <section class="login-panel"><div class="login-card"><h2>Sign in</h2><p class="muted">Choose any demo role and enter any password.</p><div class="field"><label>Email / Role</label><select id="loginRole" class="select">${Object.entries(roles).map(([k,r])=>`<option value="${k}">${r.label}</option>`).join('')}</select></div><div class="field"><label>Password</label><input class="input" type="password" value="demo123"></div><button class="btn btn-primary" style="width:100%;margin-top:8px" onclick="login()">Open CRM Dashboard →</button><div class="demo-users">${Object.entries(roles).map(([k,r])=>`<button class="demo-pill" onclick="$('#loginRole').value='${k}'">${r.label}</button>`).join('')}</div></div></section>
 </div>`;
}
function login(){db.currentRole=$('#loginRole').value;db.currentPage=(nav[db.currentRole]||nav.admin)[0];localStorage.setItem('cliniccore_logged','1');addLog(`Logged in as ${roles[db.currentRole].label}`,'Auth','Low');render();}
function logout(){localStorage.removeItem('cliniccore_logged');renderLogin();}
function switchRole(r){db.currentRole=r;db.currentPage=nav[r][0];save();addLog(`Switched role to ${roles[r].label}`,'Auth','Low');render();}
function go(p){db.currentPage=p;save();render();}
function head(){const i=pageInfo[db.currentPage]||['Page','',''];return `<div class="page-head"><div><h1>${i[2]} ${i[0]}</h1><p class="muted">${i[1]}</p></div><div class="actions">${primaryAction()}</div></div>`;}
function primaryAction(){const p=db.currentPage; if(['patients'].includes(p))return `<button class="btn btn-primary" onclick="patientModal()">+ New Patient</button>`; if(['appointments','bookAppointment'].includes(p))return `<button class="btn btn-primary" onclick="appointmentModal()">+ Book Appointment</button>`; if(p==='queue')return `<button class="btn btn-primary" onclick="queueModal()">+ Add Walk-in</button>`; if(['consultations'].includes(p))return `<button class="btn btn-primary" onclick="consultationModal()">+ New Consultation</button>`; if(['invoices','billingLite'].includes(p))return `<button class="btn btn-primary" onclick="invoiceModal()">+ New Invoice</button>`; if(p==='employees')return `<button class="btn btn-primary" onclick="employeeModal()">+ New Employee</button>`; return `<button class="btn" onclick="resetDemo()">Reset Demo</button>`;}
function page(){return head()+route(db.currentPage);}
function route(p){
 if(['dashboard','doctorDashboard','receptionDashboard','patientDashboard','hrDashboard','financeDashboard','securityDashboard','reports'].includes(p)) return dashboard(p);
 if(p==='patients') return patientsPage(); if(p==='appointments'||p==='bookAppointment') return appointmentsPage(); if(p==='queue') return queuePage(); if(p==='consultations'||p==='myRecords') return consultationsPage(); if(p==='prescriptions') return prescriptionsPage(); if(p==='hr'||p==='employees') return employeesPage(); if(p==='finance'||p==='invoices'||p==='billingLite'||p==='myInvoices') return invoicesPage(); if(p==='security'||p==='audit') return auditPage(); if(p==='notifications') return notificationsPage(); if(p==='leave') return leavePage(); if(p==='pricing') return pricingPage(); if(p==='access') return accessPage(); if(p==='backups') return backupsPage(); if(p==='schedules') return schedulesPage(); if(p==='payments') return paymentsPage(); if(p==='lab') return labPage(); return settingsPage();
}
function metric(title,val,change='Live'){return `<div class="card metric"><div class="metric-top"><span>${title}</span><span>↗</span></div><div class="metric-value">${val}</div><div class="metric-change">${change}</div></div>`;}
function dashboard(type){
 const rev=db.invoices.filter(i=>i.status==='Paid').reduce((a,i)=>a+i.total,0); const unpaid=db.invoices.filter(i=>i.status!=='Paid').length;
 let metrics = [metric('Patients',db.patients.length,'CRM records'),metric('Today Appointments',db.appointments.filter(a=>a.date===todayISO()).length,'scheduled today'),metric('Waiting Queue',db.queue.filter(q=>q.status!=='Completed').length,'active tickets'),metric('Revenue',money(rev),'paid invoices')];
 if(type==='doctorDashboard') metrics=[metric('My Patients Today',db.appointments.length,'appointments'),metric('Waiting',db.queue.length,'in queue'),metric('Completed Consults',db.consultations.length,'records'),metric('Prescriptions',db.prescriptions.length,'active')];
 if(type==='financeDashboard') metrics=[metric('Paid Revenue',money(rev),'collected'),metric('Unpaid Invoices',unpaid,'needs follow-up'),metric('Invoices',db.invoices.length,'total'),metric('Avg Invoice',money(Math.round(db.invoices.reduce((a,i)=>a+i.total,0)/db.invoices.length)),'average')];
 if(type==='securityDashboard') metrics=[metric('Audit Events',db.audit.length,'tracked'),metric('Open Alerts',db.alerts.filter(a=>a.status==='Open').length,'security'),metric('Failed Logins',db.audit.filter(a=>a.action.includes('Failed')).length,'last 24h'),metric('Backups',db.backups.length,'completed')];
 if(type==='hrDashboard') metrics=[metric('Employees',db.employees.length,'active staff'),metric('Leave Requests',db.leave.length,'requests'),metric('Doctors',db.doctors.length,'available staff'),metric('Payroll',money(db.employees.reduce((a,e)=>a+e.salary,0)),'monthly')];
 return `<div class="grid grid-4">${metrics.join('')}</div><div class="split" style="margin-top:16px"><div class="card"><h2>Operational Snapshot</h2>${chart([32,48,39,62,55,70,61])}</div><div class="card"><h2>Quick Actions</h2><div class="actions"><button class="btn btn-primary" onclick="appointmentModal()">Book appointment</button><button class="btn" onclick="patientModal()">Add patient</button><button class="btn" onclick="queueModal()">Add walk-in</button><button class="btn" onclick="invoiceModal()">Create invoice</button><button class="btn" onclick="go('audit')">View audit</button></div><hr style="border:0;border-top:1px solid var(--line);margin:18px 0"><h3>Recent activity</h3><div class="timeline">${db.audit.slice(0,5).map(l=>`<div class="timeline-item"><div class="dot"></div><div><b>${esc(l.action)}</b><div class="mini">${esc(l.user)} • ${esc(l.module)} • ${esc(l.time)}</div></div></div>`).join('')}</div></div></div><div class="grid grid-2" style="margin-top:16px"><div class="card"><h2>Today Appointments</h2>${appointmentsTable(db.appointments.slice(0,5))}</div><div class="card"><h2>Live Queue</h2>${queueMini()}</div></div>`;
}
function chart(vals){const max=Math.max(...vals);return `<div class="chart">${vals.map(v=>`<div class="bar" style="height:${(v/max)*170}px"><span>${v}</span></div>`).join('')}</div>`}
function queueMini(){return db.queue.map(q=>`<div class="queue-card"><b>${q.ticket} — ${patientName(q.patientId)}</b><small>${doctorName(q.doctorId)} • ETA ${q.eta} min</small><div style="margin-top:8px">${badge(q.status)} ${badge(q.priority)}</div></div>`).join('')||'<p class="muted">No queue tickets.</p>'}
function patientsPage(){return `<div class="card"><h2>Patient Records</h2>${table(['Code','Name','Phone','Blood','Insurance','Risk','Actions'],db.patients.map(p=>[p.code,p.name,p.phone,p.blood,p.insurance,p.chronic==='None'?badge('Low'):badge('Clinical'),`<button class="btn" onclick="patientDetails('${p.id}')">Open</button> <button class="btn" onclick="patientModal('${p.id}')">Edit</button>`]))}</div>`;}
function appointmentsTable(rows){return table(['Time','Patient','Doctor','Reason','Status','Actions'],rows.map(a=>[`${a.date} ${a.time}`,patientName(a.patientId),doctorName(a.doctorId),a.reason,badge(a.status),`<button class="btn" onclick="updateAppointment('${a.id}','Checked In')">Check-in</button>`]));}
function appointmentsPage(){return `<div class="card"><h2>Appointment Calendar</h2>${appointmentsTable(db.appointments)}</div>`;}
function queuePage(){const lanes=['Waiting','Called','In Consultation','Completed'];return `<div class="kanban">${lanes.map(l=>`<div class="lane"><h3>${l}</h3>${db.queue.filter(q=>(q.status===l)||(l==='Waiting'&&q.status==='In Queue')).map(q=>`<div class="queue-card"><b>${q.ticket} — ${patientName(q.patientId)}</b><small>${doctorName(q.doctorId)} • ${q.priority} • ETA ${q.eta} min</small><div class="actions"><button class="btn" onclick="queueStatus('${q.id}','Called')">Call</button><button class="btn" onclick="queueStatus('${q.id}','In Consultation')">Start</button><button class="btn btn-green" onclick="queueStatus('${q.id}','Completed')">Done</button></div></div>`).join('')||'<p class="muted">Empty lane</p>'}</div>`).join('')}</div>`;}
function consultationsPage(){return `<div class="card"><h2>Consultation Records</h2>${table(['Date','Patient','Doctor','Diagnosis','Treatment','Follow-up','Actions'],db.consultations.map(c=>[c.date,patientName(c.patientId),doctorName(c.doctorId),c.diagnosis,c.treatment,c.follow||'-',`<button class="btn" onclick="consultationModal('${c.id}')">Open</button>`]))}</div>`;}
function prescriptionsPage(){return `<div class="card"><h2>Prescriptions</h2>${table(['Date','Patient','Doctor','Medicine','Dosage','Frequency','Duration'],db.prescriptions.map(r=>[r.date,patientName(r.patientId),doctorName(r.doctorId),r.medicine,r.dosage,r.frequency,r.duration]))}</div>`;}
function employeesPage(){return `<div class="card"><h2>Employees</h2>${table(['Name','Role','Department','Contract','Salary','Status','Actions'],db.employees.map(e=>[e.name,e.role,e.department,e.contract,money(e.salary),badge(e.status),`<button class="btn" onclick="employeeModal('${e.id}')">Edit</button>`]))}</div>`;}
function invoicesPage(){return `<div class="card"><h2>Invoices</h2>${table(['Number','Date','Patient','Doctor','Service','Total','Status','Actions'],db.invoices.map(i=>[i.number,i.date,patientName(i.patientId),doctorName(i.doctorId),i.service,money(i.total),badge(i.status),`<button class="btn btn-green" onclick="payInvoice('${i.id}')">Pay</button> <button class="btn" onclick="invoiceModal('${i.id}')">Edit</button>`]))}</div>`;}
function auditPage(){return `<div class="card"><h2>Audit Trail</h2>${table(['Time','User','Action','Module','Risk','IP'],db.audit.map(l=>[l.time,l.user,l.action,l.module,badge(l.risk),l.ip]))}</div>`;}
function notificationsPage(){return `<div class="card"><h2>Notifications</h2>${table(['Date','To','Message','Status','Actions'],db.notifications.map(n=>[n.date,n.to,n.text,badge(n.status),`<button class="btn" onclick="markNotification('${n.id}')">Mark read</button>`]))}</div>`;}
function leavePage(){return `<div class="card"><h2>Leave Requests</h2>${table(['Employee','Type','From','To','Status','Actions'],db.leave.map(l=>[l.employee,l.type,l.from,l.to,badge(l.status),`<button class="btn btn-green" onclick="leaveStatus('${l.id}','Approved')">Approve</button><button class="btn btn-red" onclick="leaveStatus('${l.id}','Rejected')">Reject</button>`]))}</div>`;}
function pricingPage(){return `<div class="card"><h2>Service Pricing</h2>${table(['Service','Price','Actions'],db.services.map(s=>[s.name,money(s.price),`<button class="btn" onclick="priceModal('${s.id}')">Edit</button>`]))}</div>`;}
function accessPage(){const rows=[['Manage users','Yes','No','No','No','Limited','No','View'],['Book appointments','Yes','View','Yes','Yes','No','No','No'],['Medical records','Yes','Yes','No','Own only','No','No','Audit only'],['Invoices','Yes','No','Limited','Own only','No','Yes','No'],['Audit logs','Yes','No','No','No','No','No','Yes']]; return `<div class="card"><h2>Role-Based Access Matrix</h2>${table(['Feature','Admin','Doctor','Receptionist','Patient','HR','Finance','Security'],rows)}</div>`;}
function backupsPage(){return `<div class="card"><h2>Backups</h2>${table(['Type','Status','Time','Size'],db.backups.map(b=>[b.type,badge(b.status),b.time,b.size]))}</div>`;}
function schedulesPage(){return `<div class="card"><h2>Staff Schedules</h2>${table(['Doctor','Specialty','Status','Department'],db.doctors.map(d=>[d.name,d.specialty,badge(d.status),d.department]))}</div>`;}
function paymentsPage(){return `<div class="card"><h2>Payments</h2>${table(['Invoice','Method','Amount','Status'],db.invoices.map(i=>[i.number,i.method,money(i.total),badge(i.status)]))}</div>`;}
function labPage(){return `<div class="card"><h2>Lab Requests</h2><p class="muted">Lab module prepared for tests requested from consultation forms.</p>${table(['Patient','Requested Test','Status'],[[patientName('p1'),'CBC + Lipid Panel',badge('Pending')],[patientName('p4'),'Glucose Panel',badge('Completed')]])}</div>`;}
function settingsPage(){return `<div class="card"><h2>System Settings</h2><div class="grid grid-2"><div class="field"><label>Clinic Name</label><input class="input" value="ClinicCore Medical Center"></div><div class="field"><label>Default Language</label><select class="select"><option>English</option><option>Albanian</option></select></div><div class="field"><label>Session Timeout</label><input class="input" value="30 minutes"></div><div class="field"><label>2FA</label><select class="select"><option>Enabled for Admin & Security</option><option>Enabled for all users</option></select></div></div><button class="btn btn-primary" onclick="toast('Settings saved')">Save Settings</button></div>`;}
function table(headers,rows){return `<div class="table-wrap"><table class="table"><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
function opts(arr,selected){return arr.map(x=>`<option value="${x.id}" ${x.id===selected?'selected':''}>${esc(x.name)}</option>`).join('')}
function closeModal(){$('#modalHost').innerHTML=''}
function modal(title,body,footer=''){ $('#modalHost').innerHTML=`<div class="modal-backdrop" onclick="if(event.target.className==='modal-backdrop')closeModal()"><div class="modal"><div class="modal-head"><div><h2>${title}</h2><p class="muted">Functional demo form. Saves to LocalStorage and audit log.</p></div><button class="btn" onclick="closeModal()" aria-label="Close">✕</button></div>${body}<div class="actions">${footer}</div></div></div>`;}
function patientModal(id){const p=db.patients.find(x=>x.id===id)||{};modal(id?'Edit Patient':'New Patient',`<div class="form-grid">${field('Name','name',p.name)}${field('Phone','phone',p.phone)}${field('Email','email',p.email)}${field('Gender','gender',p.gender)}${field('Date of Birth','dob',p.dob,'date')}${field('Blood Type','blood',p.blood)}${field('Allergies','allergies',p.allergies)}${field('Chronic Conditions','chronic',p.chronic)}${field('Insurance','insurance',p.insurance)}${field('Emergency Contact','emergency',p.emergency)}${field('Address','address',p.address)}</div>`,`<button class="btn btn-primary" onclick="savePatient('${id||''}')">Save Patient</button>`)}
function field(label,name,val='',type='text'){return `<div class="field"><label>${label}</label><input class="input" id="f_${name}" type="${type}" value="${esc(val||'')}"></div>`}
function getv(n){return $(`#f_${n}`)?.value.trim()||''}
function savePatient(id){let p=db.patients.find(x=>x.id===id); if(!p){p={id:uid('p'),code:`PT-${1000+db.patients.length+1}`};db.patients.push(p)} Object.assign(p,{name:getv('name'),phone:getv('phone'),email:getv('email'),gender:getv('gender'),dob:getv('dob'),blood:getv('blood'),allergies:getv('allergies'),chronic:getv('chronic'),insurance:getv('insurance'),emergency:getv('emergency'),address:getv('address')}); addLog(`${id?'Updated':'Created'} patient ${p.code}`,'Patient CRM');save();closeModal();toast('Patient saved');render();}
function appointmentModal(){modal('Book Appointment',`<div class="form-grid"><div class="field"><label>Patient</label><select class="select" id="f_patientId">${opts(db.patients)}</select></div><div class="field"><label>Doctor</label><select class="select" id="f_doctorId">${opts(db.doctors)}</select></div>${field('Date','date',todayISO(),'date')}${field('Time','time','10:30','time')}${field('Reason','reason','General consultation')}</div>`,`<button class="btn btn-primary" onclick="saveAppointment()">Book Appointment</button>`)}
function saveAppointment(){const a={id:uid('a'),patientId:getv('patientId'),doctorId:getv('doctorId'),date:getv('date'),time:getv('time'),reason:getv('reason'),status:'Confirmed',createdBy:roles[db.currentRole].label}; db.appointments.push(a); db.notifications.unshift({id:uid('n'),to:'Patient',text:`Appointment confirmed for ${a.date} at ${a.time}.`,status:'Unread',date:todayISO()}); addLog(`Booked appointment for ${patientName(a.patientId)}`,'Appointments');save();closeModal();toast('Appointment booked');render();}
function queueModal(){modal('Add Walk-in to Queue',`<div class="form-grid"><div class="field"><label>Patient</label><select class="select" id="f_patientId">${opts(db.patients)}</select></div><div class="field"><label>Doctor</label><select class="select" id="f_doctorId">${opts(db.doctors)}</select></div><div class="field"><label>Priority</label><select class="select" id="f_priority"><option>Normal</option><option>High</option><option>Emergency</option></select></div>${field('ETA Minutes','eta','15','number')}</div>`,`<button class="btn btn-primary" onclick="saveQueue()">Generate Ticket</button>`)}
function saveQueue(){const q={id:uid('q'),ticket:`${String.fromCharCode(65+Math.floor(Math.random()*3))}${String(db.queue.length+1).padStart(3,'0')}`,patientId:getv('patientId'),doctorId:getv('doctorId'),appointmentId:'Walk-in',priority:getv('priority'),status:'Waiting',eta:+getv('eta')||15,checkedIn:new Date().toLocaleTimeString().slice(0,5)}; db.queue.push(q); addLog(`Generated queue ticket ${q.ticket}`,'Queue');save();closeModal();toast('Queue ticket generated');render();}
function consultationModal(){modal('New Consultation',`<div class="form-grid"><div class="field"><label>Patient</label><select class="select" id="f_patientId">${opts(db.patients)}</select></div><div class="field"><label>Doctor</label><select class="select" id="f_doctorId">${opts(db.doctors)}</select></div>${field('Symptoms','symptoms','')}${field('Diagnosis','diagnosis','')}${field('Treatment Plan','treatment','')}${field('Follow-up Date','follow','', 'date')}</div><div class="field"><label>Doctor Notes</label><textarea class="textarea" id="f_notes"></textarea></div>`,`<button class="btn btn-primary" onclick="saveConsultation()">Save Consultation</button>`)}
function saveConsultation(){const c={id:uid('c'),appointmentId:'manual',patientId:getv('patientId'),doctorId:getv('doctorId'),date:todayISO(),symptoms:getv('symptoms'),diagnosis:getv('diagnosis'),treatment:getv('treatment'),notes:getv('notes'),follow:getv('follow')}; db.consultations.push(c); addLog(`Created consultation for ${patientName(c.patientId)}`,'Consultations');save();closeModal();toast('Consultation saved');render();}
function invoiceModal(id){const i=db.invoices.find(x=>x.id===id)||{};modal(id?'Edit Invoice':'New Invoice',`<div class="form-grid"><div class="field"><label>Patient</label><select class="select" id="f_patientId">${opts(db.patients,i.patientId)}</select></div><div class="field"><label>Doctor</label><select class="select" id="f_doctorId">${opts(db.doctors,i.doctorId)}</select></div>${field('Service','service',i.service||'General Consultation')}${field('Amount','amount',i.amount||30,'number')}${field('Discount','discount',i.discount||0,'number')}<div class="field"><label>Status</label><select class="select" id="f_status"><option ${i.status==='Unpaid'?'selected':''}>Unpaid</option><option ${i.status==='Paid'?'selected':''}>Paid</option><option>Partially Paid</option><option>Refunded</option></select></div></div>`,`<button class="btn btn-primary" onclick="saveInvoice('${id||''}')">Save Invoice</button>`)}
function saveInvoice(id){let i=db.invoices.find(x=>x.id===id); if(!i){i={id:uid('inv'),number:`INV-2026-${String(db.invoices.length+1).padStart(3,'0')}`,date:todayISO(),method:'-'};db.invoices.push(i)} const amount=+getv('amount')||0, discount=+getv('discount')||0; Object.assign(i,{patientId:getv('patientId'),doctorId:getv('doctorId'),service:getv('service'),amount,discount,tax:0,total:amount-discount,status:getv('status')}); addLog(`${id?'Updated':'Created'} invoice ${i.number}`,'Finance');save();closeModal();toast('Invoice saved');render();}
function employeeModal(id){const e=db.employees.find(x=>x.id===id)||{};modal(id?'Edit Employee':'New Employee',`<div class="form-grid">${field('Name','name',e.name)}${field('Role','role',e.role)}${field('Department','department',e.department)}${field('Contract','contract',e.contract||'Full-time')}${field('Salary','salary',e.salary||700,'number')}<div class="field"><label>Status</label><select class="select" id="f_status"><option>Active</option><option>Inactive</option></select></div></div>`,`<button class="btn btn-primary" onclick="saveEmployee('${id||''}')">Save Employee</button>`)}
function saveEmployee(id){let e=db.employees.find(x=>x.id===id); if(!e){e={id:uid('e')};db.employees.push(e)} Object.assign(e,{name:getv('name'),role:getv('role'),department:getv('department'),contract:getv('contract'),salary:+getv('salary')||0,status:getv('status')}); addLog(`${id?'Updated':'Created'} employee ${e.name}`,'HR');save();closeModal();toast('Employee saved');render();}
function priceModal(id){const s=db.services.find(x=>x.id===id);modal('Edit Service Price',`${field('Service','name',s.name)}${field('Price','price',s.price,'number')}`,`<button class="btn btn-primary" onclick="savePrice('${id}')">Save Price</button>`)}
function savePrice(id){const s=db.services.find(x=>x.id===id);s.name=getv('name');s.price=+getv('price')||0;addLog(`Updated service price ${s.name}`,'Finance');save();closeModal();toast('Price saved');render();}
function patientDetails(id){const p=db.patients.find(x=>x.id===id);modal('Patient Profile',`<div class="profile-card"><div class="big-avatar">${p.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div><div><h2 style="margin:0">${esc(p.name)}</h2><p class="muted">${p.code} • ${p.gender} • Blood ${p.blood}</p></div></div><div class="grid grid-2" style="margin-top:18px"><div class="card"><b>Contact</b><p>${esc(p.phone)}<br>${esc(p.email)}<br>${esc(p.address)}</p></div><div class="card"><b>Medical Flags</b><p>Allergies: ${esc(p.allergies)}<br>Chronic: ${esc(p.chronic)}<br>Insurance: ${esc(p.insurance)}</p></div></div><h3>Related consultations</h3>${table(['Date','Doctor','Diagnosis'],db.consultations.filter(c=>c.patientId===id).map(c=>[c.date,doctorName(c.doctorId),c.diagnosis]))}`,'')}
function updateAppointment(id,status){const a=db.appointments.find(x=>x.id===id);a.status=status; if(!db.queue.some(q=>q.appointmentId===id)){db.queue.push({id:uid('q'),ticket:`A${String(db.queue.length+1).padStart(3,'0')}`,patientId:a.patientId,doctorId:a.doctorId,appointmentId:a.id,priority:'Normal',status:'Waiting',eta:10,checkedIn:new Date().toLocaleTimeString().slice(0,5)})} addLog(`Appointment ${id} marked ${status}`,'Appointments');save();toast('Appointment updated');render();}
function queueStatus(id,status){const q=db.queue.find(x=>x.id===id);q.status=status;addLog(`Ticket ${q.ticket} moved to ${status}`,'Queue');save();toast('Queue updated');render();}
function payInvoice(id){const i=db.invoices.find(x=>x.id===id);i.status='Paid';i.method='Card';addLog(`Invoice ${i.number} paid`,'Finance');save();toast('Invoice marked paid');render();}
function leaveStatus(id,status){const l=db.leave.find(x=>x.id===id);l.status=status;addLog(`Leave request ${status}`,'HR');save();toast('Leave updated');render();}
function markNotification(id){const n=db.notifications.find(x=>x.id===id);n.status='Read';save();toast('Notification marked read');render();}
function quickSearch(q){q=q.toLowerCase().trim(); if(!q)return; const matches=[...db.patients.map(p=>['Patient',p.name,p.code]),...db.invoices.map(i=>['Invoice',i.number,patientName(i.patientId)]),...db.employees.map(e=>['Employee',e.name,e.role])].filter(x=>x.join(' ').toLowerCase().includes(q)).slice(0,4); if(q.length>2 && matches.length) toast(matches.map(m=>`${m[0]}: ${m[1]}`).join(' • '));}
function exportJSON(){const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='cliniccore-crm-data.json';a.click();}
function resetDemo(){if(confirm('Reset demo data?')){db=seed();save();localStorage.setItem('cliniccore_logged','1');toast('Demo reset');render();}}
render();
