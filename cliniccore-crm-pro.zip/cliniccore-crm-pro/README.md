# ClinicCore CRM Pro

A polished, interactive frontend prototype for a complete clinic CRM / hospital management platform based on the Clinic Queue and Appointment Management System concept.

## How to run
Open `index.html` in any browser. No installation and no backend required.

## Demo login
Choose any role from the dropdown and enter any password. The app includes separate workspaces for:

- Super Admin
- Doctor
- Receptionist
- Patient
- HR Manager
- Finance Manager
- Cybersecurity Officer

## Functional features
- Role-based dashboards
- Patient CRM records
- Appointment booking
- Live queue Kanban board
- Consultation records
- Prescriptions
- Invoices and payment status
- HR employees and leave requests
- Finance pricing and revenue
- Cybersecurity audit logs
- Access control matrix
- Backups overview
- Notifications
- LocalStorage persistence
- JSON export
- Print-friendly pages

## Important note
This is a functional frontend prototype. It is designed for presentation and Software Engineering coursework. For production use, connect it to a secure backend, database, authentication, audit logging service, and encrypted storage.
